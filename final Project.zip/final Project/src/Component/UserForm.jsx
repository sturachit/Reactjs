import React, { useState, useEffect } from 'react';

export default function UserForm() {
     // State variables to store form data
     const [email, setEmail] = useState('');
     const [password, setPassword] = useState('');

     // Function to handle form submission
     const handleSubmit = async (e) => {
          e.preventDefault();
          
          // Prepare data to send to the server
          const formData = {
               email,
               password
          };

          // Send data to the server
          try {
               const response = await fetch('http://localhost:3000/users', {
                    method: 'POST',
                    headers: {
                         'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
               });

               if (response.ok) {
                    console.log('Form data submitted successfully');
                    // Optionally, you can reset the form after successful submission
                    setEmail('');
                    setPassword('');
               } else {
                    console.error('Failed to submit form data');
               }
          } catch (error) {
               console.error('Error submitting form data:', error);
          }
     };

     useEffect(() => {
          // Perform some operation when the component mounts
          const fetchData = async () => {
               try {
                    // Example: Fetch data from the server
                    const response = await fetch('http://example.com/data');
                    const data = await response.json();
                    console.log(data);
               } catch (error) {
                    console.error('Error fetching data:', error);
               }
          };

          fetchData(); // Call the fetchData function when the component mounts
     }, []);

     return (
          <div>
               <form className='w-50 m-auto mt-5' onSubmit={handleSubmit}>
                    <div className="mb-3">
                         <label htmlFor="exampleInputEmail1" className="form-label fw-bold">
                              Email address
                         </label>
                         <input 
                              type="email" 
                              className="form-control" 
                              id="exampleInputEmail1" 
                              aria-describedby="emailHelp" 
                              placeholder='abc7@gmail.com' 
                              value={email}
                              onChange={(e) => setEmail(e.target.value)} // Handle email input change
                         />
                    </div>
                    <div className="mb-3">
                         <label htmlFor="exampleInputPassword1" className="form-label fw-bold">
                              Password
                         </label>
                         <input 
                              type="password" 
                              className="form-control" 
                              id="exampleInputPassword1" 
                              value={password}
                              onChange={(e) => setPassword(e.target.value)} // Handle password input change
                         />
                    </div>
                    <button type="submit" className="btn btn-primary">
                         Submit
                    </button>
               </form>
          </div>
     );
}
